package com.seniordesign.seniordesignuitest1;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class PO2GraphActivity extends AppCompatActivity {

    private BarChart po2Chart;

    public DataHandler getDataHandler() {
        return dataHandler;
    }

    public void setDataHandler(DataHandler dataHandler) {
        this.dataHandler = dataHandler;
    }

    private DataHandler dataHandler;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_po2_graph);

        po2Chart = findViewById(R.id.po2Chart);

        dataHandler = MainActivity.getDataHandler();

        ArrayList<BarEntry> po2Data = new ArrayList<>();
        po2Data = dataHandler.getPo2Data();

        backButton = findViewById(R.id.buttonBackPO2);

        BarDataSet barDataSet = new BarDataSet(po2Data, "Percent Blood O2 (%)");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(0f);

        BarData barData = new BarData(barDataSet);

        po2Chart.setFitBars(true);
        po2Chart.setData(barData);
        po2Chart.getDescription().setText("Blood 02");
        po2Chart.animateY(2000);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }


}
