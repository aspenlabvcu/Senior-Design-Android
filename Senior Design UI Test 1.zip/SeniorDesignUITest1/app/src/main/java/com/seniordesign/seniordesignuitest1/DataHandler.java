package com.seniordesign.seniordesignuitest1;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Random;

public class DataHandler {

    static ArrayList<Entry> hrData = new ArrayList<>();
    static ArrayList<BarEntry> bpSysData = new ArrayList<>();
    static ArrayList<BarEntry> bpDiaData = new ArrayList<>();
    static ArrayList<BarEntry> po2Data = new ArrayList<>();
    static ArrayList<Entry> rrData = new ArrayList<>();
    static float point = 0;

    public DataHandler() {
        if(point == 0){
            //Here's where you would have collect the very first sample
            int hrNum = new Random().nextInt(33) + 60;
            int bpSysNum = new Random().nextInt(34) + 95;
            int bpDiaNum = new Random().nextInt(27) + 60;
            int po2Num = new Random().nextInt(6) + 95;
            int rrNum = new Random().nextInt(5) + 11;

            hrData.add(new Entry(point, hrNum));
            bpSysData.add(new BarEntry(point, bpSysNum));
            bpDiaData.add(new BarEntry(point, bpDiaNum));
            po2Data.add(new BarEntry(point, po2Num));
            rrData.add(new Entry(point, rrNum));
        }
    }

    public void collectData(int hrNum, int bpSysNum, int bpDiaNum, int po2Num, int rrNum) {
        point = point + 1;

        hrData.add(new Entry(point, hrNum));
        bpSysData.add(new BarEntry(point, bpSysNum));
        bpDiaData.add(new BarEntry(point, bpDiaNum));
        po2Data.add(new BarEntry(point, po2Num));
        rrData.add(new Entry(point, rrNum));
    }

    public ArrayList<Entry> getHrData() {
        return hrData;
    }

    public ArrayList<BarEntry> getBpSysData() {
        return bpSysData;
    }

    public ArrayList<BarEntry> getBpDiaData() {
        return bpDiaData;
    }

    public ArrayList<BarEntry> getPo2Data() {
        return po2Data;
    }

    public ArrayList<Entry> getRrData() {
        return rrData;
    }

    public float getPoint() {
        return point;
    }
}
