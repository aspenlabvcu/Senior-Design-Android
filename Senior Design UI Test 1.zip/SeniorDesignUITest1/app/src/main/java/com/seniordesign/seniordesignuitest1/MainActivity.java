package com.seniordesign.seniordesignuitest1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    public static DataHandler dataHandler;
    private TextView heartRateValue;
    private TextView bloodPressureValue;
    private TextView pulseO2Value;
    private TextView respiratoryRateValue;
    private Button generateData;
    private CardView hrCard;
    private CardView bpCard;
    private CardView po2Card;
    private CardView rrCard;

    public static DataHandler getDataHandler() {
        return dataHandler;
    }

    public static void setDataHandler(DataHandler dataHandler) {
        MainActivity.dataHandler = dataHandler;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataHandler = new DataHandler();

        heartRateValue = findViewById(R.id.hrValue);
        bloodPressureValue = findViewById(R.id.bpValue);
        pulseO2Value = findViewById(R.id.po2Value);
        respiratoryRateValue = findViewById(R.id.rrValue);

        hrCard = findViewById(R.id.hrCard);
        bpCard = findViewById(R.id.bpCard);
        po2Card = findViewById(R.id.po2Card);
        rrCard = findViewById(R.id.rrCard);

        generateData = findViewById(R.id.buttonGenerateData);

        generateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hrNum = new Random().nextInt(33) + 60;
                int bpSysNum = new Random().nextInt(34) + 95;
                int bpDiaNum = new Random().nextInt(27) + 60;
                int pO2Num = new Random().nextInt(6) + 95;
                int rrNum = new Random().nextInt(5) + 11;

                heartRateValue.setText(hrNum + " BPM");
                bloodPressureValue.setText(bpSysNum + "/" + bpDiaNum + " mmHg");
                pulseO2Value.setText(pO2Num + "%");
                respiratoryRateValue.setText(rrNum + " Breaths per Minute");

                dataHandler.collectData(hrNum, bpSysNum, bpDiaNum, pO2Num, rrNum);
            }
        });

        po2Card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PO2GraphActivity.class);
                startActivity(intent);
            }
        });

        hrCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HRGraphActivity.class);
                startActivity(intent);
            }
        });

        rrCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HRGraphActivity.class);
                startActivity(intent);
            }
        });

        bpCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), BPGraphActivity.class);
                startActivity(intent);
            }
        });
    }



}