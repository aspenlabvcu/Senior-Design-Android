package com.seniordesign.seniordesignuitest1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class HRGraphActivity extends AppCompatActivity {

    private LineChart hrChart;

    public DataHandler getDataHandler() {
        return dataHandler;
    }

    public void setDataHandler(DataHandler dataHandler) {
        this.dataHandler = dataHandler;
    }

    private DataHandler dataHandler;
    private Button backButtonHR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hr_graph);

        hrChart = findViewById(R.id.hrChart);

        dataHandler = MainActivity.getDataHandler();

        ArrayList<Entry> hrData = new ArrayList<>();
        hrData = dataHandler.getHrData();

        backButtonHR = findViewById(R.id.buttonBackHR);

        LineDataSet lineDataSet = new LineDataSet(hrData, "Heart Rate (BPM)");
        lineDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        lineDataSet.setValueTextColor(Color.BLACK);
        lineDataSet.setValueTextSize(0f);

        LineData lineData = new LineData(lineDataSet);

        hrChart.setData(lineData);
        hrChart.getDescription().setText("Heart Rate");
        hrChart.animateXY(1750, 1750);

        backButtonHR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }


}