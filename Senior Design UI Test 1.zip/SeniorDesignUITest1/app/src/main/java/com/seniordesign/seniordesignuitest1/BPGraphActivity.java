package com.seniordesign.seniordesignuitest1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class BPGraphActivity extends AppCompatActivity {


    private BarChart bpChart;

    public DataHandler getDataHandler() {
        return dataHandler;
    }

    public void setDataHandler(DataHandler dataHandler) {
        this.dataHandler = dataHandler;
    }

    private DataHandler dataHandler;
    private Button backButtonBP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bp_graph);

        bpChart = findViewById(R.id.bpChart);

        dataHandler = MainActivity.getDataHandler();

        ArrayList<BarEntry> bpSysData = new ArrayList<>();
        ArrayList<BarEntry> bpDiaData = new ArrayList<>();
        bpSysData = dataHandler.getBpSysData();
        bpDiaData = dataHandler.getBpDiaData();

        backButtonBP = findViewById(R.id.buttonBackBP);

        BarDataSet barDataSet = new BarDataSet(bpSysData, "Blood Pressure (mmHg)");
        for (int i=0; i<bpDiaData.size(); i++){
            barDataSet.addEntry(bpDiaData.get(i));
        }

        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(10f);

        BarData barData = new BarData(barDataSet);

        bpChart.setFitBars(true);
        bpChart.setData(barData);
        bpChart.getDescription().setText("Blood Pressure");
        bpChart.animateY(1750);

        backButtonBP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }
}