package com.seniordesign.seniordesignuitest1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class RRGraphActivity extends AppCompatActivity {

    private LineChart rrChart;

    public DataHandler getDataHandler() {
        return dataHandler;
    }

    public void setDataHandler(DataHandler dataHandler) {
        this.dataHandler = dataHandler;
    }

    private DataHandler dataHandler;
    private Button backButtonRR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hr_graph);

        rrChart = findViewById(R.id.rrChart);

        dataHandler = MainActivity.getDataHandler();

        ArrayList<Entry> rrData = new ArrayList<>();
        rrData = dataHandler.getRrData();

        backButtonRR = findViewById(R.id.buttonBackRR);

        LineDataSet lineDataSet = new LineDataSet(rrData, "Respiratory Rate (Breaths Per Minute)");
        lineDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        lineDataSet.setValueTextColor(Color.BLACK);
        lineDataSet.setValueTextSize(0f);

        LineData lineData = new LineData(lineDataSet);

        rrChart.setData(lineData);
        rrChart.getDescription().setText("Respiratory Rate");
        rrChart.animateXY(1750, 1750);

        backButtonRR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }
}