package app.seniordesign.seniordesignbluetoothtest1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.garmin.android.connectiq.IQDevice;

import java.util.List;

public class DeviceRecViewAdapter extends RecyclerView.Adapter<DeviceRecViewAdapter.ViewHolder> {

    private List<IQDevice> deviceList;

    private Context context;
    private ViewGroup content;


    @NonNull
    @Override
    public DeviceRecViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.devices_list_item, parent,false);
        content = parent;
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull DeviceRecViewAdapter.ViewHolder holder, int position) {
        int pos = position;
        holder.deviceName.setText(deviceList.get(pos).getFriendlyName());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, deviceList.get(pos).getFriendlyName() + " Selected", Toast.LENGTH_SHORT).show();
                MainActivity.selectedDevice = deviceList.get(pos);

                ((ViewGroup) content.getParent()).removeView(content);
            }
        });
    }

    @Override
    public int getItemCount() {
        return deviceList.size();
    }

    public void setDeviceList(List<IQDevice> deviceList) {
        this.deviceList = deviceList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView deviceName;
        private CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            deviceName = itemView.findViewById(R.id.deviceName);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}
