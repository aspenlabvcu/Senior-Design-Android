package app.seniordesign.seniordesignbluetoothtest1;


import static com.garmin.android.connectiq.ConnectIQ.IQConnectType.WIRELESS;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.garmin.android.connectiq.ConnectIQ;
import com.garmin.android.connectiq.IQDevice;
import com.garmin.android.connectiq.exception.InvalidStateException;
import com.garmin.android.connectiq.exception.ServiceUnavailableException;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView heartRateValue;
    private TextView bloodPressureValue;
    private TextView pulseO2Value;
    private TextView respiratoryRateValue;
    private Button pairWatch;
    private Button pairSensor;
    private Button generateData;

    private Context context;

    public List<IQDevice> connectedDevices;
    public static IQDevice selectedDevice;

    public IQDevice getSelectedDevice() {
        return selectedDevice;
    }

    public void setSelectedDevice(IQDevice selectedDevice) {
        MainActivity.selectedDevice = selectedDevice;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        heartRateValue = findViewById(R.id.heartRateValue);
        bloodPressureValue = findViewById(R.id.bloodPressureValue);
        pulseO2Value = findViewById(R.id.pulseO2Value);
        respiratoryRateValue = findViewById(R.id.respRateValue);

        pairWatch = findViewById(R.id.connectWatch);
        pairSensor = findViewById(R.id.connectSensor);

        generateData = findViewById(R.id.generateRandomData);

        generateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hrNum = new Random().nextInt(33) + 60;
                int bpSysNum = new Random().nextInt(34) + 95;
                int bpDiaNum = new Random().nextInt(27) + 60;
                int pO2Num = new Random().nextInt(6) + 95;
                int rrNum = new Random().nextInt(5) + 11;

                heartRateValue.setText(hrNum + " BPM");
                bloodPressureValue.setText(bpSysNum + "/" + bpDiaNum + " mmHg");
                pulseO2Value.setText(pO2Num + "%");
                respiratoryRateValue.setText(rrNum + " Breaths per Minute");
            }
        });

        pairWatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectIQ connectIQ;
                connectIQ = ConnectIQ.getInstance(context, WIRELESS);

                connectIQ.initialize(context, true, new ConnectIQ.ConnectIQListener() {
                    // Called when the SDK has been successfully initialized
                    @Override
                    public void onSdkReady() {

                        // Do any post initialization setup.
                        Toast.makeText(context, "Garmin Mobile SDK Successfully Initialized", Toast.LENGTH_SHORT).show();

                        try {
                            List<IQDevice> deviceList = connectIQ.getKnownDevices();

                            if(deviceList != null && deviceList.size() > 0) {
                                for  (IQDevice device : deviceList) {
                                    IQDevice.IQDeviceStatus status = connectIQ.getDeviceStatus(device);
                                    if (status == IQDevice.IQDeviceStatus.CONNECTED) {
                                        connectedDevices.add(device);
                                    }
                                }
                            }
                        } catch (InvalidStateException e) {
                            e.printStackTrace();
                        } catch (ServiceUnavailableException e) {
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void onInitializeError(ConnectIQ.IQSdkErrorStatus iqSdkErrorStatus) {
                        Toast.makeText(context, "Garmin Mobile SDK Failed to Initialize", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onSdkShutDown() {

                    }

                });
            }
        });
    }
}