package app.seniordesign.seniordesignbluetoothtest1;

import androidx.fragment.app.Fragment;

/**
 * This fragment controls Bluetooth to communicate with other devices
 */
public class BluetoothCommFragment extends Fragment {
    private static final String TAG = "BluetoothCommFragment";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_ENABLE_BT = 3;

    // Layout Views

}
